import { FMEAHeader } from './components/FMEAHeader';
import { FMEAForm } from './components/FMEAForm';
import { FMEAGuide } from './components/FMEAGuide';

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 max-w-7xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-center">FMEA 분석 도구</h1>
          <p className="text-center text-muted-foreground mt-2">
            AIAG 표준에 따른 고장모드 및 영향분석 (Failure Mode and Effects Analysis)
          </p>
        </div>
        <FMEAHeader />
        <FMEAForm />
        <FMEAGuide />
      </div>
    </div>
  );
}